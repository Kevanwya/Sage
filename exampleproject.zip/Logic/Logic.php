<?php
session_start(); // Start the session

$db = mysqli_connect("localhost", "root", "", "TropicalNomad");
if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

//variables for login
$username = $password = "";


//variables for signup
$username = $password = $conpassword = "";

//variables for staff signup
$F_name = $L_name = $email = $phone = $position = "";

//variables for customer signup
$C_F_Name = $C_L_Name = $C_email = $C_phone = "";

//variables for add and edit tour
$tour_name = $start_date = $end_date = $price = $description = "";

$tour_id = $edit_id = "";

//variables for booking
$number_of_people = $tour_id = "";




if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['Signup_1'])) {

    // Sanitize user input to prevent SQL injection
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $password = mysqli_real_escape_string($db, $_POST['password']);
    $conpassword = mysqli_real_escape_string($db, $_POST['conpassword']);

    // Error handling for empty fields
    if (empty($username) || empty($password) || empty($conpassword)) {
        echo "All fields are required.";
        exit;
    }

    if ($password === $conpassword) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (username, password) VALUES ('$username', '$hashed_password')";
        if (mysqli_query($db, $sql)) {
            // Fetch the user ID of the newly created user
            $query = "SELECT user_id FROM users WHERE username='$username'";
            $result = mysqli_query($db, $query);
            
            if ($result && mysqli_num_rows($result) > 0) {
                $_SESSION['username'] = $username; // Store username in session
                $_SESSION['userid'] = mysqli_fetch_assoc($result)['user_id']; // Store user ID in session
            } else {
                echo "Error fetching user ID.";
                exit;
            }

            echo "New record created successfully";
            header("Location: Cust_signup.php");
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($db);
        }
    } else {
        echo "Passwords do not match.";
    }
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['Signup_2'])) {

    // Sanitize user input to prevent SQL injection
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $password = mysqli_real_escape_string($db, $_POST['password']);
    $conpassword = mysqli_real_escape_string($db, $_POST['conpassword']);

    // Error handling for empty fields
    if (empty($username) || empty($password) || empty($conpassword)) {
        echo "All fields are required.";
        exit;
    }

    if ($password === $conpassword) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (username, password) VALUES ('$username', '$hashed_password')";
        if (mysqli_query($db, $sql)) {
            // Fetch the user ID of the newly created user
            $query = "SELECT user_id FROM users WHERE username='$username'";
            $result = mysqli_query($db, $query);
            if ($result && mysqli_num_rows($result) > 0) {
                $_SESSION['username'] = $username; // Store username in session
                $_SESSION['userid'] = mysqli_fetch_assoc($result)['user_id']; // Store user ID in session
            } else {
                echo "Error fetching user ID.";
                exit;
            }

            echo "New record created successfully";
            header("Location: Staff_Signup.php");
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($db);
        }
    } else {
        echo "Passwords do not match.";
    }
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//staff signup
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['Staff_Signup'])) {

    // Sanitize user input to prevent SQL injection
    $F_name = mysqli_real_escape_string($db, $_POST['F_name']);
    $L_name = mysqli_real_escape_string($db, $_POST['L_name']);
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $phone = mysqli_real_escape_string($db, $_POST['phone']);
    $position = mysqli_real_escape_string($db, $_POST['position']);

    // Error handling for empty fields
    if (empty($F_name) || empty($L_name) || empty($email) || empty($phone) || empty($position)) {
        echo "All fields are required.";
        exit;
    }

    // Ensure $_SESSION['userid'] is set
    if (!isset($_SESSION['userid']) || empty($_SESSION['userid'])) {
        echo "User ID is not set in the session.";
        exit;
    }

    // Insert into staff table
    $sql = "INSERT INTO staff (user_id, first_name, last_name, email, phone_number, position) VALUES ('" . $_SESSION['userid'] . "', '$F_name', '$L_name', '$email', '$phone', '$position')";
    if (mysqli_query($db, $sql)) {
        echo "New record created successfully";
        header("Location: Home_Staff.php");
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($db);
    }
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//customer signup
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['Cust_Signup'])) {

    // Sanitize user input to prevent SQL injection
    $C_F_Name = mysqli_real_escape_string($db, $_POST['C_F_Name']);
    $C_L_Name = mysqli_real_escape_string($db, $_POST['C_L_Name']);
    $C_email = mysqli_real_escape_string($db, $_POST['C_email']);
    $C_phone = mysqli_real_escape_string($db, $_POST['C_phone']);

    // Error handling for empty fields
    if (empty($C_F_Name) || empty($C_L_Name) || empty($C_email) || empty($C_phone)) {
        echo "All fields are required.";
        exit;
    }

    // Ensure $_SESSION['userid'] is set
    if (!isset($_SESSION['userid']) || empty($_SESSION['userid'])) {
        echo "User ID is not set in the session.";
        exit;
    }

    // Insert into customers table
    $sql = "INSERT INTO customers (user_id, C_first_name, C_last_name, C_email, C_phone_number) VALUES ('" . $_SESSION['userid'] . "', '$C_F_Name', '$C_L_Name', '$C_email', '$C_phone')";
    if (mysqli_query($db, $sql)) {
        echo "New record created successfully";
        header("Location: Home_Customer.php");
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($db);
    }
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['Login'])) {

    // Sanitize user input to prevent SQL injection
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $password = mysqli_real_escape_string($db, $_POST['password']);

    // Error handling for empty fields
    if (empty($username) || empty($password)) {
        echo "All fields are required.";
        exit;
    }

    // Fetch the user record from the database
    $query = "SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($db, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);

        // Verify the password
        if (password_verify($password, $user['password'])) {
            $_SESSION['username'] = $username; // Store username in session
            $_SESSION['userid'] = $user['user_id']; // Store user ID in session

            // Check if the user is a staff member
            $query = "SELECT user_id FROM staff WHERE user_id='" . $_SESSION['userid'] . "'";
            $result = mysqli_query($db, $query);

            if ($result && mysqli_num_rows($result) > 0) {

                $query = "SELECT staff_id FROM staff WHERE user_id='" . $_SESSION['userid'] . "'";  
                $result = mysqli_query($db, $query);
                if ($result && mysqli_num_rows($result) > 0) {
                    $_SESSION['staff_id'] = mysqli_fetch_assoc($result)['staff_id']; // Store staff ID in session
                    header("Location: Home_Staff.php"); // Redirect to staff page
                } else {
                    echo "Error fetching staff ID.";
                    exit;
                }
            } else {
                // Check if the user is a customer
                $query = "SELECT user_id FROM customers WHERE user_id='" . $_SESSION['userid'] . "'";
                $result = mysqli_query($db, $query);
                if ($result && mysqli_num_rows($result) > 0) {
                    $query = "SELECT customer_id FROM customers WHERE user_id='" . $_SESSION['userid'] . "'";  
                    $result = mysqli_query($db, $query);
                    if ($result && mysqli_num_rows($result) > 0) {
                        $_SESSION['customer_id'] = mysqli_fetch_assoc($result)['customer_id']; // Store customer ID in session
                        header("Location: Home_Customer.php"); // Redirect to customer page
                    } else {
                        echo "Error fetching customer ID.";
                        exit;
                    }
                } else {
                    echo "User is neither a staff member nor a customer.";
                }

            }
        } else {
            echo "Invalid username or password.";
        }
    } else {
        echo "Invalid username or password.";
    }
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//logout

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['logout'])) {
    // Destroy the session and redirect to the login page
    session_unset(); // Unset all session variables
    session_destroy(); // Destroy the session
    header("Location: index.php"); // Redirect to login page
    exit;
    
}
    
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//Functions 
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//Add tour
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_tour'])){
    header("Location: add.php");
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add'])){

    $tour_name = mysqli_real_escape_string($db, $_POST['tour_name']);
    $start_date = mysqli_real_escape_string($db, $_POST['start_date']);
    $end_date = mysqli_real_escape_string($db, $_POST['end_date']);
    $price = mysqli_real_escape_string($db, $_POST['price']);
    $description = mysqli_real_escape_string($db, $_POST['description']);

    if (empty($tour_name) || empty($start_date) || empty($end_date) || empty($price) || empty($description)) {
        echo "All fields are required.";
        exit;
    }

    $sql = "INSERT INTO tours (tour_name, start_date, end_date, price, description) VALUES ('$tour_name', '$start_date', '$end_date', '$price', '$description')";
    if (mysqli_query($db, $sql)) {
        echo "New tour added successfully";
        header("Location: Tours.php");
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($db);
    }
}   

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//edit tour

//edit tour
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_tour'])){
    $tour_id = isset($_POST['tour_id']) ? $_POST['tour_id'] : '';

    if (empty($tour_id)) {
        echo "Tour ID is required.";
        exit;
    }

    // Redirect to edit.php with tour_id as a parameter
    header("Location: edit.php?tour_id=" . $tour_id);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])){
    $tour_id = mysqli_real_escape_string($db, $_POST['tour_id']);
    $tour_name = mysqli_real_escape_string($db, $_POST['tour_name']);
    $start_date = mysqli_real_escape_string($db, $_POST['start_date']);
    $end_date = mysqli_real_escape_string($db, $_POST['end_date']);
    $price = mysqli_real_escape_string($db, $_POST['price']);
    $description = mysqli_real_escape_string($db, $_POST['description']);

    if (empty($tour_id) || empty($tour_name) || empty($start_date) || empty($end_date) || empty($price) || empty($description)) {
        echo "All fields are required.";
        exit;
    }

    $sql = "UPDATE tours SET tour_name='$tour_name', start_date='$start_date', end_date='$end_date', price='$price', description='$description' WHERE tour_id='$tour_id'";
    if (mysqli_query($db, $sql)) {
        echo "Tour updated successfully";
        header("Location: Tours.php");
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($db);
    }
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//edit customer

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_customer'])) {
    $customer_id = isset($_POST['customer_id']) ? $_POST['customer_id'] : '';

    if (empty($customer_id)) {
        echo "Customer ID is required.";
        exit;
    }

    // Redirect to edit_customer.php with customer_id as a parameter
    header("Location: edit_customer.php?customer_id=" . $customer_id);
    exit;
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------------------------------------------
//add bookings

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['book_tour'])){
    // Get the tour_id from the form submission
    $tour_id = isset($_POST['tour_id']) ? $_POST['tour_id'] : '';
    
    if (empty($tour_id)) {
        echo "Tour ID is required.";
        exit;
    }
    
    // Redirect to book_tour.php with tour_id as a parameter
    header("Location: book_tour.php?tour_id=" . $tour_id);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['book'])) {
    $tour_id = mysqli_real_escape_string($db, $_POST['tour_id']);
    $number_of_people = mysqli_real_escape_string($db, $_POST['number_of_people']);
    $total_price = mysqli_real_escape_string($db, $_POST['total_price']); // Get the total price from the form

    if (empty($tour_id) || empty($number_of_people) || empty($total_price)) {
        echo "All fields are required.";
        exit;
    }

    // Insert booking into the database
    $sql = "INSERT INTO bookings (customer_id, tour_id, number_of_people, total_price) 
            VALUES ('" . $_SESSION['customer_id'] . "', '$tour_id', '$number_of_people', '$total_price')";
    if (mysqli_query($db, $sql)) {
        echo "Booking confirmed successfully";
        header("Location: Home_Customer.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($db);
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_booking'])) {
    $booking_id = mysqli_real_escape_string($db, $_POST['booking_id']);

    if (empty($booking_id)) {
        echo "Booking ID is required.";
        exit;
    }

    $sql = "DELETE FROM bookings WHERE booking_id='$booking_id'";
    if (mysqli_query($db, $sql)) {
        echo "Booking deleted successfully.";
        header("Location: Bookings.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($db);
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_booking'])) {
    $booking_id = isset($_POST['booking_id']) ? $_POST['booking_id'] : '';

    if (empty($booking_id)) {
        echo "Booking ID is required.";
        exit;
    }

    // Redirect to edit_booking.php with booking_id as a parameter
    header("Location: edit_booking.php?booking_id=" . $booking_id);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_tour'])) {
    $tour_id = mysqli_real_escape_string($db, $_POST['tour_id']);

    if (empty($tour_id)) {
        echo "Tour ID is required.";
        exit;
    }

    $sql = "DELETE FROM tours WHERE tour_id='$tour_id'";
    if (mysqli_query($db, $sql)) {
        echo "Tour deleted successfully.";
        header("Location: Tours.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($db);
    }
}