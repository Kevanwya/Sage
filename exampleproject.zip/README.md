Task list

**CSS** - Melady

1. **Admin Login System** - **Caleb**

- New user registration
- Login form with username & password (stored in DB)
- Session handling
- Logged-in user’s username visible on all dashboard pages
- Logout functionality

2. **Admin Dashboard Features** - **Nathan** **Kyle**

Include the ability to:
- View total number of tours, customers, and bookings
- Add, view, edit, and delete records for:
    - Tour Types (e.g., Waterfall, Volcano, Coastal)
    - Tours (Tour name, description, date, price, and type)
    - Customers (Name, Email, Phone)
    - Bookings (Select tour, customer, date, status)

3. **Summary & Reports** - **Zane** **Kevan**
- A Bookings Summary Table that shows a JOIN of customer, tour, and
booking details

4. **Validation & Security**
- Basic form validation (no empty fields)
- SQL injection protection (e.g., mysqli_real_escape_string or prepared
statements)
- Display friendly error/success messages
