<?php
include('../Logic/Logic.php');

$id=$_REQUEST['user_id'];
$query = "DELETE FROM customers WHERE id=$id"; 
$result = mysqli_query($con,$query) or die ( mysqli_error($con));
header("Location: Customers.php.php"); 
exit();
?>