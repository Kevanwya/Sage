<?php
include('../Logic/Logic.php');

$id=$_REQUEST['user_id'];
$query = "DELETE FROM tours WHERE id=$id"; 
$result = mysqli_query($con,$query) or die ( mysqli_error($con));
header("Location: tour.php.php"); 
exit();
?>