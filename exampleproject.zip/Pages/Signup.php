<?php 

include('../Logic/Logic.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/signup.css">
    <title>Tropical Normad - Signup</title>
</head>
<body>
    
    
<form action="" method="post">

    <label for="username">Username:</label><br>
    <input type="text" id="username" name="username"><br><br>
    <label for="password">Password:</label><br>
    <input type="password" id="password" name="password"><br><br>
    <label for conpassword>Confirm Password:</label><br>
    <input type="password" id="conpassword" name="conpassword"><br><br>
    <input type="submit" name="Signup_1" value="New Customer">
    <input type="submit" name="Signup_2" value="New Staff"><br><br>
    <P>Already a Member?<button>Login</button></P>
</form>

</body>
</html>