<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tropical Nomad - Welcome</title>
    <link rel="stylesheet" href="../CSS/index.css">
</head>
<body>
    
<h1>Welcome to Tropical Nomad</h1>
        <p>Adventure awaits! Discover the beauty of the islands with our unforgettable tours.</p>
    
        <li><a href="login.php">Log In</a></li>
        <li><a href="signup.php">Sign Up</a></li>

</body>
</html>

