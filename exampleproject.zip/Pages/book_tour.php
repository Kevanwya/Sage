<?php 
    include('../Logic/Logic.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/tourlist.css">
    <title>Book Tour</title>

</head>
<body>
    <h2 style="text-align:center;">Book Tour</h2>

    <?php 
        // Check if tour_id is set in the URL or POST data
        if (isset($_GET['tour_id'])) {
            $tour_id = mysqli_real_escape_string($db, $_GET['tour_id']);
        } elseif (isset($_POST['tour_id'])) {
            $tour_id = mysqli_real_escape_string($db, $_POST['tour_id']);
        } else {
            echo "<p>Error: No tour ID provided.</p>";
            exit;
        }

        // Query to get tour details
        $query = "SELECT * FROM tours WHERE tour_id = '$tour_id'";
        $result = mysqli_query($db, $query);
        
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            
            // Display tour details and booking form in a table
            echo "<table>";
            echo "<tr><th colspan='5'>Tour Details</th></tr>";
            echo "<tr><th>Tour Name</th><th>Start Date</th><th>End Date</th><th>Price</th><th>Description</th></tr>";
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['tour_name']) . "</td>";
            echo "<td>" . htmlspecialchars($row['start_date']) . "</td>";
            echo "<td>" . htmlspecialchars($row['end_date']) . "</td>";
            echo "<td>$" . htmlspecialchars($row['price']) . "</td>";
            echo "<td>" . htmlspecialchars($row['description']) . "</td>";
            echo "</tr>";
            echo "</table>";
            
            echo "<table>";
            echo "<tr><th colspan='2'>Complete Your Booking</th></tr>";
            echo "<form action='' method='post'>";
            echo "<tr><td>Number of People:</td><td><input type='number' name='number_of_people' min='1' value='1' required></td></tr>";
            echo "<tr><td>Total Price:</td><td>$<span id='total_price'>" . htmlspecialchars($row['price']) . "</span></td></tr>";
            echo "<input type='hidden' name='tour_id' value='" . htmlspecialchars($row['tour_id']) . "'>";
            echo "<input type='hidden' name='total_price' id='hidden_total_price' value='" . htmlspecialchars($row['price']) . "'>";
            echo "<tr><td colspan='2'><input type='submit' name='book' value='Confirm Booking'></td></tr>";
            echo "</form>";
            echo "</table>";
            
            // JavaScript to calculate total price
            echo "<script>
                document.querySelector('input[name=\"number_of_people\"]').addEventListener('change', function() {
                    var price = " . $row['price'] . ";
                    var people = this.value;
                    var totalPrice = (price * people).toFixed(2);
                    document.getElementById('total_price').textContent = totalPrice;
                    document.getElementById('hidden_total_price').value = totalPrice;
                });
            </script>";
        } else {
            echo "<p>No tour found with the given ID.</p>";
        }
    ?>
    
    <a href='Home_Customer.php'>Back to Home</a>
</body>
</html>