<?php

include('../Logic/Logic.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/tourlist.css">
    <title>Bookings</title>
</head>
<body>
    <h1>Bookings</h1>
    
    <table>
        <tr>
            <th>Booking ID</th>
            <th>Tour ID</th>
            <th>Customer First Name</th>
            <th>Customer Last Name</th>
            <th>Booking Date</th>
            <th>Number of People</th>
            <th colspan="2">Admin Options</th>
        </tr>
        <?php
        $query = "
            SELECT 
                bookings.booking_id, 
                bookings.tour_id, 
                customers.C_first_name, 
                customers.C_last_name, 
                bookings.booking_date, 
                bookings.number_of_people 
            FROM 
                bookings
            INNER JOIN 
                customers 
            ON 
                bookings.customer_id = customers.customer_id
            INNER JOIN 
                tours 
            ON 
                bookings.tour_id = tours.tour_id
        ";
        $result = mysqli_query($db, $query);

        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<tr>
                        <td>' . htmlspecialchars($row['booking_id']) . '</td>
                        <td>' . htmlspecialchars($row['tour_id']) . '</td>
                        <td>' . htmlspecialchars($row['C_first_name']) . '</td>
                        <td>' . htmlspecialchars($row['C_last_name']) . '</td>
                        <td>' . htmlspecialchars($row['booking_date']) . '</td>
                        <td>' . htmlspecialchars($row['number_of_people']) . '</td>
                        <td>
                            <form method="post">
                                <input type="hidden" name="booking_id" value="' . htmlspecialchars($row['booking_id']) . '">
                                <input type="submit" name="edit_booking" value="Edit">
                            </form>
                        </td>
                        <td>
                            <form method="post">
                                <input type="hidden" name="booking_id" value="' . htmlspecialchars($row['booking_id']) . '">
                                <input type="submit" name="delete_booking" value="Delete">
                            </form>
                        </td>
                      </tr>';
            }
            if (mysqli_num_rows($result) > 0) {
                echo '<tr><th colspan="8">Bookings table</th></tr>
                      <tr><th colspan="8">Number of bookings = ' . mysqli_num_rows($result) . '</th></tr>';
            } else {
                echo '<tr><th colspan="8">No bookings found.</th></tr>';
            }
        } else {
            echo 'Error: ' . mysqli_error($db);
        }
        ?>
    </table>

</body>
</html>