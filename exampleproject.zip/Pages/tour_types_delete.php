<?php
include('../Logic/Logic.php');

$id=$_REQUEST['user_id'];
$query = "DELETE FROM tour_types WHERE id=$id"; 
$result = mysqli_query($con,$query) or die ( mysqli_error($con));
header("Location: Home_Staff.php"); 
exit();
?>