<?php
include('../Logic/Logic.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/homecus.css">
    <title>Tropical Normad - Home</title>
</head>
<body>
    
    <h1>Home Customer</h1>

    <table border="1" width="100%">
        <tr>
            <th>

            </th>
            <th>
                <?php echo htmlspecialchars($_SESSION['username'])?>
            </th>
            <th>
                <form action="" method="post">
                    <input type="submit" name="Logout" id="Logout" value="Logout">
                </form>
            </th>
        </tr>
    </table>

    <?php 
    
    $query = "SELECT * FROM tours"; 
    $result = mysqli_query($db, $query);

    if(mysqli_num_rows($result) > 0) {
        echo "<table border='1' width='100%'>";
        echo "<tr><th>Tour Name</th><th>Price</th><th>Duration</th><th>Booking</th></tr>";
        while($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['tour_name']) . "</td>";
            echo "<td>" . htmlspecialchars($row['price']) . "</td>";
            echo "<td>" . htmlspecialchars($row['duration']) . "</td>";
            echo "<form action='book_tour.php' method='post'>";
            echo "<input type='hidden' name='tour_id' value='" . htmlspecialchars($row['tour_id']) . "'>";
            echo "<td><input type='submit' name='book_tour' value='Book Tour'></td>";
            echo "</form></td>";
            
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No tours available.";
    }

    
    ?>


</body>
</html>