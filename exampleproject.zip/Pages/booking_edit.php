<?php
include('../Logic/Logic.php');

// Check if tour_id is provided in the URL
if (!isset($_GET['tour_id']) || empty($_GET['tour_id'])) {
    echo "Tour ID is not provided.";
    exit;
}

$tour_id = mysqli_real_escape_string($db, $_GET['tour_id']);
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Update Record</title>
    <link rel="stylesheet" href="../CSS/edit.css">
</head>

<body>
    <div class="form">
        <h2>Update Tour Details</h2>
        <form method="post" action="">
            <?php 
            $query = "SELECT * FROM tours WHERE tour_id = '$tour_id'";
            $result = mysqli_query($db, $query);
            
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
            } else {
                echo "<p>No tour found with the given ID.</p>";
                exit;
            }
            ?>
            
            <input type="hidden" name="tour_id" value="<?php echo htmlspecialchars($tour_id); ?>">
            
            <label for="tour_name">Tour Name:</label>
            <input type="text" id="tour_name" name="tour_name" value="<?php echo htmlspecialchars($row['tour_name']) ?>" required>
            <br><br>

            <label for="start_date">Start Date and Time:</label>
            <input type="datetime" id="start_date" name="start_date" value="<?php echo htmlspecialchars($row['start_date']) ?>" required>
            <br><br>

            <label for="end_date">End Date and Time:</label>
            <input type="datetime" id="end_date" name="end_date" value="<?php echo htmlspecialchars($row['end_date']) ?>" required>
            <br><br>

            <label for="price">Price:</label>
            <input type="text" id="price" name="price" value="<?php echo htmlspecialchars($row['price']) ?>" required>
            <br><br>

            <label for="description">Description:</label>
            <input type="text" id="description" name="description" value="<?php echo htmlspecialchars($row['description']) ?>" required>
            <br><br>

            <input type="submit" name="update" value="Update">
        </form>
    </div>
</body>

</html>