<?php
include('../Logic/Logic.php');

// Check if customer_id is provided in the URL
if (!isset($_GET['customer_id']) || empty($_GET['customer_id'])) {
    echo "Customer ID is not provided.";
    exit;
}

$customer_id = mysqli_real_escape_string($db, $_GET['customer_id']);
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Update Record</title>
    <link rel="stylesheet" href="../CSS/edit.css">
</head>

<body>
    <div class="form">
        <h2>Update Customer Details</h2>
        <form method="post" action="">
            <?php 
            $query = "SELECT * FROM customers WHERE customer_id = '$customer_id'";
            $result = mysqli_query($db, $query);
            
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
            } else {
                echo "<p>No customer found with the given ID.</p>";
                exit;
            }
            ?>

            <input type="hidden" name="customer_id" value="<?php echo htmlspecialchars($customer_id); ?>">
            
            <label for="C_first_name">First Name:</label>
            <input type="text" id="C_first_name" name="C_first_name" value="<?php echo htmlspecialchars($row['C_first_name']) ?>" required>
            <br><br>

            <label for="C_last_name">Last Name:</label>
            <input type="text" id="C_last_name" name="C_last_name" value="<?php echo htmlspecialchars($row['C_last_name']) ?>" required>
            <br><br>

            <label for="C_email">Email:</label>
            <input type="email" id="C_email" name="C_email" value="<?php echo htmlspecialchars($row['C_email']) ?>" required>
            <br><br>

            <label for="C_phone_number">Phone Number:</label>
            <input type="text" id="C_phone_number" name="C_phone_number" value="<?php echo htmlspecialchars($row['C_phone_number']) ?>" required>
            <br><br>

            <input type="submit" name="update" value="Update">
        </form>
    </div>
</body>

</html>