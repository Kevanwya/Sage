<?php
include('../Logic/Logic.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/add.css">
    <title>Document</title>
</head>

<body>
    <!--ADD tours-->

    <form action="" method="post">

        <label for="tour_name">Tour Name: </label>
        <input type="text" name="tour_name"> <br>

        <label for="start_date">Start Date:</label>
        <input type="datetime-local" name="start_date"><br>

        <label for="end_date">End Date: </label>
        <input type="datetime-local" name="end_date"> <br>

        <label for="price">Price: </label>
        <input type="text" name="price"> <br>

        <label for="description">Description: </label>
        <input type="text" name="description"> <br>

        <input type="submit" name="add" value="Add tour">
    </form>

</body>

</html>