<?php
include('../Logic/Logic.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/tourlist.css">
    <title>Document</title>
</head>

<body>
    <?php
    $query = "SELECT * FROM customers";
    $result = mysqli_query($db, $query);
    if ($result) {
        echo '<table>';
        echo '<tr><th>Customer ID</th><th colspan="2">Name</th><th>Email</th><th>Phone</th><th colspan="2">Admin Options</th></tr>';
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<tr>
                    <td>' . htmlspecialchars($row['customer_id']) . '</td>
                    <td>' . htmlspecialchars($row['C_first_name']) . '</td>
                    <td>' . htmlspecialchars($row['C_last_name']) . '</td>
                    <td>' . htmlspecialchars($row['C_email']) . '</td>
                    <td>' . htmlspecialchars($row['C_phone_number']) . '</td>
                    <td>
                        <form method="post">
                            <input type="hidden" name="customer_id" value="' . htmlspecialchars($row['customer_id']) . '">
                            <input type="submit" name="edit_customer" value="Edit">
                        </form>
                    </td>
                    <td>
                        <form method="post">
                            <input type="hidden" name="customer_id" value="' . htmlspecialchars($row['customer_id']) . '">
                            <input type="submit" name="delete_customer" value="Delete">
                        </form>
                    </td>
                  </tr>';
        }
        if (mysqli_num_rows($result) > 0) {
            echo '<tr><th colspan="6">Customers table</th></tr><tr><th colspan="6">Number of customers = ' . mysqli_num_rows($result) . '</th></tr>';
        } else {
            echo '<tr><th colspan="6">No customers found.</th></tr>';
        }
        echo '</table>';
    } else {
        echo 'Error: ' . mysqli_error($db);
    }
    ?>
</body>

</html>