<?php
include('../Logic/Logic.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/tourlist.css">
    <title>Document</title>
</head>

<body>
    <Table>
        <tr>
            <th colspan="8">
                Tour List
            </th>
        </tr>
        <tr>
            <th colspan="8">
                <form action="" method="post">
                    <input type="submit" name="add_tour" value="Add Tour">
                </form>
            </th>
        </tr>
        <?php
        $query = "SELECT * FROM tours";
        $result = mysqli_query($db, $query);

        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['tour_name']) . "</td>";
                echo "<td>" . htmlspecialchars($row['start_date']) . "</td>";
                echo "<td>" . htmlspecialchars($row['end_date']) . "</td>";
                echo "<td>" . htmlspecialchars($row['price']) . "</td>";
            echo "<td>" . htmlspecialchars($row['description']) . "</td>";
            echo "<td>
                <form action='tour_delete.php' method='POST'>
                    <input type='hidden' name='id' value='123'> 
                    <button type='submit'>Delete</button>
                </form>
            </td>";
                echo "<td>
                        <form method='post'>
                        <input type='hidden' name='tour_id' value='" . htmlspecialchars($row['tour_id']) . "'>
                        <input type='submit' name='edit_tour' value='Edit'>
                        </form>
                        </td>";
                echo "<td>
                        <form method='post'>
                        <input type='hidden' name='tour_id' value='" . htmlspecialchars($row['tour_id']) . "'>
                        <input type='submit' name='delete' value='Delete'>
                        </form>
                        </td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No tours found.</td></tr>";
        }
        ?>
    </Table>
</body>

</html>