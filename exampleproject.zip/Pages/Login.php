<?php 

include('../Logic/Logic.php');
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/login.css">
    <title>Tropical Nomad - Login</title>
</head>
<body>
    
<form action="" method="post">

    <label for="username">Username:</label><br>
    <input type="text" id="username" name="username"><br><br>
    <label for="password">Password:</label><br>
    <input type="password" id="password" name="password"><br><br>
    <input type="submit" name="Login" value="Submit">

</form>
<P>New Member? <a href="signup.php">Signup</a></P>
<a href="">Forget password</a>




</body>
</html>