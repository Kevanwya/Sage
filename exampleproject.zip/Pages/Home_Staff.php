<?php

include('../Logic/Logic.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tropical Normad - Home</title>
    <link rel="stylesheet" href="../CSS/homestaff.css">
</head>

<body>

    <!--header-->

    <table>
        <tr>
            <th>HOME</th>
            <th>Welcome <?php echo htmlspecialchars($_SESSION['username']) ?></th>
            <th>Account <br>
                <form action="" method="post">
                    <input type="submit" name="logout" value="Logout">
                </form>
            </th>
        </tr>
    </table>

    <table>
        <tr>
            <th width="25%"><a href="Bookings.php">Bookings</a></th>
            <th width="25%"><a href="Customers.php">Customers</a></th>
            <th width="25%"><a href="Tours.php">Tours</a></th>
            <th colspan="2" width="25%"><a href="Tour_Types.php">Tour Types</a></th>
        </tr>

        <tr>
            <th colspan="5">Upcoming tours</th>
        </tr>
        <tr>
            <th>Tour Name</th>
            <th>Tour Date and time</th>
            <th>Number of customers</th>
            <th colspan="2">Admin Options</th>
        </tr>
        <?php
        $query = "
            SELECT 
                tours.tour_id, 
                tours.tour_name, 
                tours.start_date, 
                tours.end_date, 
                bookings.number_of_people
            FROM 
                bookings
            INNER JOIN 
                tours
            ON 
                bookings.tour_id = tours.tour_id
            WHERE 
                tours.start_date > NOW()
            ORDER BY 
                tours.start_date ASC
            LIMIT 3
        ";
        $result = mysqli_query($db, $query);

        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['tour_name']) . "</td>";
                echo "<td>" . htmlspecialchars($row['start_date']) . "</td>";
                echo "<td>" . htmlspecialchars($row['number_of_people']) . "</td>";
                echo "<td> <form action='' method='post'>
                    <input type='hidden' name='tour_id' value='" . htmlspecialchars($row['tour_id']) . "'>
                    <input type='submit' name='view_tour' value='View Tour'>
                </form></td>";
                echo "<td> <form action='tour_types_delete.php' method='post'>
                    <input type='hidden' name='tour_id' value='" . htmlspecialchars($row['tour_id']) . "'>
                    <input type='submit' name='delete_tour' value='Delete Tour'>
                </form></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='3'>No upcoming tours found.</td></tr>";
        }
        ?>
    </table>

</body>

</html>