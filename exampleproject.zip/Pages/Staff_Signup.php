<?php 

include('../Logic/Logic.php');
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/staffsignup.css">
    <title>Tropical Normad - Signup Staff</title>
</head>
<body>
    
    <form action="" method="post">
        <label for="F_name">First name</label>
        <input type="text" id="F_name" name="F_name"><br><br>
        <label for="L_name">Last name</label>
        <input type="text" id="L_name" name="L_name"><br><br>
        <label for="email">Email</label>
        <input type="email" id="email" name="email"><br><br>
        <label for="phone">Phone Number</label>
        <input type="tel" id="phone" name="phone"><br><br>
        Label Position
        <select id="position" name="position">
            <option value="Manager">Manager</option>
            <option value="Staff">Staff</option>
            <option value="Admin">Admin</option>
        </select><br><br>
        <input type="submit" name="Staff_Signup" value="Submit">
        <P>Already a Member?<button>Login</button></P>
    </form>

</body>
</html>