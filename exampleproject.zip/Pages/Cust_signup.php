<?php 

include('../Logic/Logic.php');
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tropical Normad - Signup Customer</title>
    <link rel="stylesheet" href="../CSS/customer.css">
</head>
<body>

<form action="" method="post">

    <label for="C_F_Name">First Name</label>
    <input type="text" id="C_F_Name" name="C_F_Name"><br><br>
    <label for="C_L_Name">Last Name</label>
    <input type="text" id="C_L_Name" name="C_L_Name"><br><br>
    <label for="C_email">Email</label>
    <input type="email" id="C_email" name="C_email"><br><br>
    <label for="C_phone">Phone Number</label>
    <input type="tel" id="C_phone" name="C_phone"><br><br>
    <input type="submit" name="Cust_Signup" value="Submit">
    <P>Already a Member?<button>Login</button></P>

</form>
    
</body>
</html>