<?php
include('../Logic/Logic.php');

// Check if tour_type_id is provided in the URL
if (!isset($_GET['tour_type_id']) || empty($_GET['tour_type_id'])) {
    echo "Tour Type ID is not provided.";
    exit;
}

$tour_type_id = mysqli_real_escape_string($db, $_GET['tour_type_id']);
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Update Record</title>
    <link rel="stylesheet" href="../CSS/edit.css">
</head>

<body>
    <div class="form">
        <h2>Update Tour Type Details</h2>
        <form method="post" action="">
            <?php 
            $query = "SELECT * FROM tour_types WHERE tour_type_id = '$tour_type_id'";
            $result = mysqli_query($db, $query);
            
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
            } else {
                echo "<p>No tour type found with the given ID.</p>";
                exit;
            }
            ?>
            
            <input type="hidden" name="tour_type_id" value="<?php echo htmlspecialchars($tour_type_id); ?>">
            
            <label for="tour_type_name">Tour Type Name:</label>
            <input type="text" id="tour_type_name" name="tour_type_name" value="<?php echo htmlspecialchars($row['tour_type_name']) ?>" required>
            <br><br>

            <input type="submit" name="update" value="Update">
        </form>
    </div>
</body>

</html>